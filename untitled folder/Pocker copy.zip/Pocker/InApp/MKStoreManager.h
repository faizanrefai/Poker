
#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>
#import "MKStoreObserver.h"

// CONFIGURATION STARTS -- Change this in your app
#define kConsumableBaseFeatureId @"com.demo.poker"//@"com.mycompany.myapp."




#define kFeatureA1Id @""








//@"com.mobiletuts.inapptestingdemo.1"@"com.mycompany.myapp.featureA"
#define kFeatureA2Id @"com.guestlist.inappdemo.11"//@"com.mobiletuts.inapptestingdemo.2"
#define kFeatureA3Id @"com.guestlist.inappdemo.12"
#define kFeatureA4Id @"com.guestlist.inappdemo.13"
#define kFeatureA5Id @"com.guestlist.inappdemo.14"
#define kFeatureA6Id @"com.guestlist.inappdemo.15"
#define kFeatureA7Id @"com.guestlist.inappdemo.16"
#define kFeatureA8Id @"com.guestlist.inappdemo.17"
#define kFeatureA9Id @"com.guestlist.inappdemo.18"

//com.demo.poker

#define kFeatureA10Id @"com.guestlist.inappdemo.19"
#define kFeatureA11Id @"com.guestlist.inappdemo.20"
#define kFeatureA12Id @"com.guestlist.inappdemo.21"
#define kFeatureA13Id @"com.guestlist.inappdemo.22"
#define kFeatureA14Id @"com.guestlist.inappdemo.23"
#define kFeatureA15Id @"com.guestlist.inappdemo.24"
#define kFeatureA16Id @"com.guestlist.inappdemo.25"
#define kFeatureA17Id @"com.guestlist.inappdemo.26"
#define kFeatureA18Id @"com.guestlist.inappdemo.27"
#define kFeatureA19Id @"com.guestlist.inappdemo.28"
#define kFeatureA20Id @"com.guestlist.inappdemo.29"
#define kFeatureA21Id @"com.guestlist.inappdemo.30"
#define kFeatureA22Id @"com.guestlist.inappdemo.31"
#define kFeatureA23Id @"com.guestlist.inappdemo.32"
#define kFeatureA24Id @"com.guestlist.inappdemo.33"
#define kFeatureA25Id @"com.guestlist.inappdemo.34"
#define kFeatureA26Id @"com.guestlist.inappdemo.35"
#define kFeatureA27Id @"com.guestlist.inappdemo.36"
#define kFeatureA28Id @"com.guestlist.inappdemo.37"
#define kFeatureA29Id @"com.guestlist.inappdemo.38"
#define kFeatureA30Id @"com.guestlist.inappdemo.39"
#define kFeatureA31Id @"com.guestlist.inappdemo.40"
#define kFeatureA32Id @"com.guestlist.inappdemo.41"
#define kFeatureA33Id @"com.guestlist.inappdemo.42"
#define kFeatureA34Id @"com.guestlist.inappdemo.43"
#define kFeatureA35Id @"com.guestlist.inappdemo.44"
#define kFeatureA36Id @"com.guestlist.inappdemo.45"
#define kFeatureA37Id @"com.guestlist.inappdemo.46"
#define kFeatureA38Id @"com.guestlist.inappdemo.47"
#define kFeatureA39Id @"com.guestlist.inappdemo.48"
#define kFeatureA40Id @"com.guestlist.inappdemo.49"
#define kFeatureA41Id @"com.guestlist.inappdemo.50"
#define kFeatureA42Id @"com.guestlist.inappdemo.51"
#define kFeatureA43Id @"com.guestlist.inappdemo.52"
#define kFeatureA44Id @"com.guestlist.inappdemo.53"
//#define kConsumableFeatureBId @"com.mycompany.myapp.005"
// consumable features should have only number as the last part of the product name
// MKStoreKit automatically keeps track of the count of your consumable product

#define SERVER_PRODUCT_MODEL 0
// CONFIGURATION ENDS -- Change this in your app

@protocol MKStoreKitDelegate <NSObject>
@optional
- (void)productFetchComplete;
- (void)productPurchased:(NSString *)productId;
- (void)transactionCanceled;
// as a matter of UX, don't show a "User Canceled transaction" alert view here
// use this only to "enable/disable your UI or hide your activity indicator view etc.,
@end

@interface MKStoreManager : NSObject<SKProductsRequestDelegate> {

	NSMutableArray *_purchasableObjects;
	MKStoreObserver *_storeObserver;
	
	BOOL isProductsAvailable;
}

@property (nonatomic, retain) NSMutableArray *purchasableObjects;
@property (nonatomic, retain) MKStoreObserver *storeObserver;

// These are the methods you will be using in your app
+ (MKStoreManager*)sharedManager;

// this is a static method, since it doesn't require the store manager to be initialized prior to calling
+ (BOOL) isFeaturePurchased:(NSString*) featureId; 

// these three are not static methods, since you have to initialize the store with your product ids before calling this function
- (void) buyFeature:(NSString*) featureId;
- (NSMutableArray*) purchasableObjectsDescription;
- (void) restorePreviousTransactions;

- (BOOL) canConsumeProduct:(NSString*) productIdentifier quantity:(int) quantity;
- (BOOL) consumeProduct:(NSString*) productIdentifier quantity:(int) quantity;


//DELEGATES
+(id)delegate;	
+(void)setDelegate:(id)newDelegate;

@end
