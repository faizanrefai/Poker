//
//  onIphone.h
//  VideoApp
//
//  Created by Ronak Arora on 20/06/12.
//  Copyright 2012 iverve. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface onIphone : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource,UITextViewDelegate,UITableViewDelegate,UITableViewDataSource> {
    
    IBOutlet UITextView *textbox;
    IBOutlet UILabel *dateLabel;
    IBOutlet UIActivityIndicatorView *indicator;
    IBOutlet UILabel *moreInfiLabel;
    IBOutlet UITableViewCell *moreInfocell;
    IBOutlet UITableView *myTable;
    IBOutlet UIToolbar *toolbar;
    IBOutlet UITextView *quesText;
    IBOutlet UITextView *answerText;
    NSMutableArray *moreQueArry;
}

- (IBAction)backPress:(id)sender;

- (IBAction)sendPressed:(id)sender;

@end
